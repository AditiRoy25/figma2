import React from 'react'

const DynamicLoading = () => {
  return (
    <div>Laoding....</div>
  )
}

export default DynamicLoading