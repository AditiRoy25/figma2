import { useEffect, useReducer } from "react";
import CartContext from "./CreatecartContext";
import Api from "../../../api/Api";

const initialState = {
  cart: [],
  loading: true,
};
function reducer(state, action) {
  switch (action.type) {
    case "set_cart":
      return;

    case "add_to_cart":
      return;

    case "remove_cart":
      return;

    default:
      return state;
  }
}

export const Cartprovider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);
  
  useEffect(()=>{
    const fetchData = async ()=>{
const response = await Api.get("/cart");
console.log("carts", response?.data);
dispatch({type: "set_cart", payload: response.data})
    }
fetchData();
  }, [])
  return <CartContext.Provider value={{}}>{children}</CartContext.Provider>;
};
