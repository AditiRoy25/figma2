import React from 'react'

const Dashboard = () => {
    // const [count, setCount] = useState(0)
  return (
    <div>Dashboard</div>
  )
}

export default Dashboard